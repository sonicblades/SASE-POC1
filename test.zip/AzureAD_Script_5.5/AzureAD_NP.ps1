﻿Get-Module
try{
import-module .\iac-azure-mcas\PS-Scripts\Manage_AWT-CASB-NON-Prod.psm1
import-module .\iac-azure-mcas\PS-Scripts\Manage_AWT-CASBVault-NON-Prod.psm1
import-module .\AzureAD\2.0.2.106\AzureAD.psd1
import-module .\Az.Accounts\2.6.2\Az.Accounts.psd1
#import-module .\Az.KeyVault\3.6.1\Az.KeyVault.psd1
} 
catch
{ Write-Host "Modules are not correctly imported. Please validate the path and privileges." }
Get-Module
#Connect-AzureAD
try 
#{ $var = Get-AzureADTenantDetail } 
{ $tenantid= "059e96c9-9dfd-44ce-9bab-9a23021a8081"
Connect-AzureAD -TenantId $tenantid
}
catch [Microsoft.Open.Azure.AD.CommonLibrary.AadNeedAuthenticationException] 
#{ Write-Host "You're not connected"; Connect-AzureAD }
{ Write-Host "You're not connected"; Connect-AzAccount
$tenantid= "059e96c9-9dfd-44ce-9bab-9a23021a8081"
Connect-AzureAD -TenantId $tenantid
 }

try 

{ $VaultLogin = Invoke-Expression -Command ".\vault login -method=oidc -path=azure-ad -address=https://vault-onprem-nonprod-active.res.bngf.local/" 2>&1>$null | out-null
  $token = $(.\vault.exe kv get -address="https://vault-onprem-nonprod-active.res.bngf.local" -field apiv1 secret/applications/5934/non_production/development/NP-API)
}
catch [Microsoft.Open.Azure.AD.CommonLibrary.AadNeedAuthenticationException] 
{ Write-Host "Hashicorp login failed"}

function Show-MemoryReport {

Clear-Variable -name ans
Clear-Variable -name usr
Clear-Variable -name Age
Clear-Variable -name grp
Clear-Variable -name rmu
Clear-Variable -name usrl
Clear-Variable -name Age
cls

do{
$Age = Read-Host "
  _______                      _____           _____ ____  
 |__   __|                    / ____|   /\    / ____|  _ \ 
    | | ___  __ _ _ __ ___   | |       /  \  | (___ | |_) |
    | |/ _ \/  _` | '_ `  _ \  | |      / /\ \  \___ \|  _ < 
    | |  __/ (_| | | | | | | | |____ / ____ \ ____) | |_) |
    |_|\___|\__,_|_| |_| |_|  \_____/_/    \_\_____/|____/ 
                                                           
                                                           
What brings you here today ?

1. I want to add users to an AzureAD group 
2. I want to remove users from an AzureAd group
3. I want to see users of an AzureAD group
4. I want to export users of an AzureAD group
5. I want to add an AzureAD group
6. I want to remove an AzureAD group
7. I want to Add an Owner to All CASB group
8. I want to Remove An Owner from All CASB group
9. I want to see the steering config
10. Output All CASB Group Details
11. I want to compare two AzureAD groups
"
}
while ($Age -ne "1" -and  $Age -ne "2" -and  $Age -ne "3" -and $Age -ne "4" -and $Age -ne "5" -and $Age -ne "6" -and $Age -ne "7" -and $Age -ne "8" -and $Age -ne "9" -and $Age -ne "10" -and $Age -ne "11")



if($Age -eq "1" )
{
do{
      $ans = Read-Host "
1. Add only one user to an Azure group
2. Add multiple users to an Azure group
"
}
while ($ans -ne "1" -and  $ans -ne "2")

if($ans -eq "1" )
{
$usr = Read-Host "
Please provide the user email"
$grp = Read-Host "
Please provide the Azure group"

AddPionnerUser -UserUPN $usr -PioneerGroup $grp

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")
if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit
}

}


else
{
try{
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
 InitialDirectory = [Environment]::GetFolderPath('Desktop')
 Filter = 'Documents (*.csv)|*.csv'
 Title = 'Select files to open 👀👀👀 Team-CASB 👀👀👀'
}
$null = $FileBrowser.ShowDialog()
$usrl = $FileBrowser.FileName
}
    catch {
    }
$grp = Read-Host "
Please provide the Azure group"


AddBulkPionnerUsers -CSVFiles $FileBrowser.FileName -PioneerGroup $grp

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")
if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit
}
}
      }



elseif ($Age -eq "2" )


      {

do{
      $ans = Read-Host "
1. Remove only one user from an Azure group
2. Remove multiple users from an Azure group
"
}
while ($ans -ne "1" -and  $ans -ne "2")

if($ans -eq "1" )
{
$rmu = Read-Host "
Please provide the user email"
$grp = Read-Host "
Please provide the Azure group"

RemovePionnerUser -UserUPN $rmu -PioneerGroup $grp
do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")
if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit
}
}


else
{
try{
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
 InitialDirectory = [Environment]::GetFolderPath('Desktop')
 Filter = 'Documents (*.csv)|*.csv'
 Title = 'Select files to open 👀👀👀 Team-CASB 👀👀👀'
}
$null = $FileBrowser.ShowDialog()
$usrl = $FileBrowser.FileName
}
    catch {
    }
$grp = Read-Host "
Please provide the Azure group."
RemoveBulkPionnerUsers -CSVFiles $FileBrowser.FileName -PioneerGroup $grp
do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")
if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit
}
}
}


elseif ($Age -eq "4" )
{
$ans = Read-Host "
Please provide the name of Azure group"

ExportPionnerList -PioneerGroup $ans

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")

if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit

}
}

elseif ($Age -eq "5" )
{
do{
      $ans = Read-Host "
1. Group For Exceptions ?
2. Group For Steering/Client Config?
"
}
while ($ans -ne "1" -and  $ans -ne "2")
if($ans -eq "1" )
{
$grpname = Read-Host "
Please provide suffix for the group (AAD-SEC-MGM-CASB-) "
$grpname = 'AAD-SEC-MGM-CASB-' + $grpname

ADDAzureADGroup -grpname $grpname

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")

if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit

}
}
else
{
$grpname = Read-Host "
Please provide suffix for the group (AAD-SEC-CASB-Netskope-) "
$grpname = 'AAD-SEC-CASB-Netskope-' + $grpname

ADDAzureADGroup -grpname $grpname

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")
if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit
}
}
}



elseif ($Age -eq "6" )
{
$grpname = Read-Host "
Please provide the name of the group"

RemoveAzureADGroup -grpname $grpname

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")

if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit

}
}

elseif ($Age -eq "7" )
{
$username = Read-Host "
Please provide the UPN of the user"

ADDAzureADGroupOwner -username $username

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")

if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit

}
}

elseif ($Age -eq "8" )
{
$username = Read-Host "
Please provide the UPN of the user"

RemoveAzureADGroupOwner -username $username

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")

if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit

}
}



elseif($Age -eq "9" )
{
do{
      $ans = Read-Host "
1. I want to see the steering config of one user
2. I want to see the steering config of multiple users
"
}
while ($ans -ne "1" -and  $ans -ne "2")

if($ans -eq "1" )
{
$usremail = Read-Host "
Please provide the user email"


FetchUserSteering -usremail $usremail -token $token

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")
if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit
}

}


else
{
try{
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
 InitialDirectory = [Environment]::GetFolderPath('Desktop')
 Filter = 'Documents (*.csv)|*.csv'
 Title = 'Select files to open 👀👀👀 Team-CASB 👀👀👀'
}
$null = $FileBrowser.ShowDialog()
$usrl = $FileBrowser.FileName
}
    catch {
    }


FetchUserSteeringbulk -csv $FileBrowser.FileName -fname $usrl -token $token

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")
if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit
}
}
      }

elseif ($Age -eq "10" )
{

CASBAzureADGroup 

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")

if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit

}
}

elseif ($Age -eq "11" )
{
$grpname1 = Read-Host "Please provide the first group name"
$grpname2 = Read-Host "Please provide the second group name"

CompareAzureADGroup -grpname1 $grpname1 -grpname2 $grpname2

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")

if($sct -eq "Y" )
{
Show-MemoryReport
}
else
{
exit

}
}

else 
{
$ans = Read-Host "
Please provide the name of Azure group"

ViewPionnerList -PioneerGroup $ans

do{
$sct = Read-Host "
You want to restart script ? (Y/N)"
}
while ($sct -ne "Y" -and  $sct -ne "N")

if($sct -eq "Y" )
{
Show-MemoryReport
}





else
{
exit
}
}

}

Show-MemoryReport