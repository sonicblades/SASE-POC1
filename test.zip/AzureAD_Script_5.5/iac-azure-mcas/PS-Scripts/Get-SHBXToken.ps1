<#	
	.NOTES
	=================================================================================================
	 Created on:   	2021-05-05
	 Created by:   	Samed Maalaoui - SR. SME O365 Security And Compliance
	 Organization: 	National Bank Of Canada
	 Filename:     	Get-SHBXToken
	=================================================================================================
	.DESCRIPTION
		Create an access token in order to authenticate against a specific session.

Versions

V1.0  - Created the function
#>#####################################################################################################

$TenantID = "EnterTenantID"
$user = "EnterAPI-ID"
$pwd = ConvertTo-SecureString "EnterSecretID" -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential($user,$pwd)


Function Get-SHBXToken{

[cmdletbinding()]
Param(
    [parameter(Mandatory=$true)]
    [pscredential]$credential,
    [parameter(Mandatory=$true)]
    [string]$tenantID
    )
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $AuthUri = "https://login.microsoftonline.com/$TenantID/oauth2/token"
    $Resource = 'graph.microsoft.com'
    $AuthBody = "grant_type=client_credentials&client_id=$($credential.UserName)&client_secret=$($credential.GetNetworkCredential().Password)&resource=https%3A%2F%2F$Resource%2F"
    
    
    $Response = Invoke-RestMethod -Method Post -Uri $AuthUri -Body $AuthBody
    If($Response.access_token){
        return $Response.access_token
    }
    Else{
        Throw "Authentication failed"
    }
}
$SHBXToken =  Get-SHBXToken -credential $credential -tenantID $TenantID
