<#	
	.NOTES
	================================================================================================================
	 Created on:   	2021-06-22
	 Created by:   	Samed Maalaoui - SR. SME O365 Security And Compliance
	 Organization: 	National Bank Of Canada
	 Filename:     	Manage_AWT-CASBPioneers
	================================================================================================================
	.DESCRIPTION
		Provide a central management tool to the CloudSec team to enable them to autonomously manage Pioneer groups

Versions
 V1.0  - The ability to inject one user at a time (add)
 V1.1  - The ability to remove one user at a time (removal)
 V1.2  - The ability to add and remove multiple users
 V1.3  - Add a function to show the list of users within a pioneer group

Requirements
 Please download and install the Azure AD module before performing these functions: Install-Module -Name AzureAD
 You need to run Powershell as administrator to start the installation 

Synopsis
 Connect AzureAD
 To connect to Azure AD, please run : RunAADConnection

 Add One User    : AddPionnerUser -UserUPN samed.maalaoui@bnc.ca -PionnierGroup AAD-SEC-CASB-Netskope-Pionnier-AWT-W3
                  AddPionnerUser -UserUPN "samed.maalaoui@bnc.ca" -PionnierGroup "AAD-SEC-CASB-Netskope-Pionnier-AWT-W3"

 Remove One User : RemovePionnerUser -UserUPN samed.maalaoui@bnc.ca -PionnierGroup AAD-SEC-CASB-Netskope-Pionnier-AWT-W3
                  RemovePionnerUser -UserUPN "samed.maalaoui@bnc.ca" -PionnierGroup "AAD-SEC-CASB-Netskope-Pionnier-AWT-W3"
                  
 Add multiple Users    : AddBulkPionnerUsers -CSVFiles C:\Temp\PionnerUserList.csv -PionnierGroup AAD-SEC-CASB-Netskope-Pionnier-AWT-W3
                        AddBulkPionnerUsers -CSVFiles "C:\Temp\PionnerUserList.csv" -PionnierGroup "AAD-SEC-CASB-Netskope-Pionnier-AWT-W3" 
                     
 Remove multiple Users : RemoveBulkPionnerUsers  -CSVFiles C:\Temp\PionnerUserList.csv -PionnierGroup AAD-SEC-CASB-Netskope-Pionnier-AWT-W3
                        RemoveBulkPionnerUsers  -CSVFiles "C:\Temp\PionnerUserList.csv" -PionnierGroup "AAD-SEC-CASB-Netskope-Pionnier-AWT-W3"                     

#>#####################################################################################################################


function RunAADConnection{

    Param(
    [parameter(mandatory=$false)]
        
        [string]$AzureModule
        )
        Import-Module AzureAD
		Connect-AzureAD
    }
function AddPionnerUser{

    Param(
    [parameter(mandatory=$True)]
        
        [string]$UserUPN,
        [string]$PioneerGroup
        )
        $UserUPN = $UserUPN.Trim()
        $PioneerGroup = $PioneerGroup.Trim()
        try 
            { 
            if ((Get-AzureADUser -Filter "UserPrincipalName eq '$UserUPN'") -ne $null)
                {$UserUPN = (Get-AzureADUser -Filter "UserPrincipalName eq '$UserUPN'").UserPrincipalName
                    }
            elseif((Get-AzureADUser -Filter "mail eq '$UserUPN'") -ne $null)
                {$UserUPN = (Get-AzureADUser -Filter "mail eq '$UserUPN'").UserPrincipalName
                    }
            else 
                {$UserUPN = Get-AzureADUser -ObjectId $UserUPN
                    }
            } 

         catch [Microsoft.Open.AzureAD16.Client.ApiException] 
                { Write-Host "User" $UserUPN "does not exist in AzureAD" -ForegroundColor Red  
                ;return} 
        if ((Get-AzureADGroup  -Filter "DisplayName eq '$PioneerGroup'") -eq $null)
        {
        Write-Host "The group" $PioneerGroup "does not exist in AzureAD" -ForegroundColor Red
        ;return
        }


        try {
        $ShellConnetion = Get-AzureADTenantDetail    
        $AADSecGroup = Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'"
        $AADUser  = Get-AzureADUser -Filter "UserPrincipalName eq '$UserUPN'"
        $Cid = ((Get-AzureADCurrentSessionInfo).Account).Id
        $glist = (Get-AzureADGroupOwner -ObjectId (Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'").ObjectID -All $true).UserPrincipalName 


        if ($glist -inotcontains $Cid)
        {
        Write-Host "You do not have permission to do this task, please validate your privileges for this group" $PioneerGroup -ForegroundColor Red 
        ;return
        }
        elseif ((Get-AzureADGroupMember -ObjectId (Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'").ObjectId -All $true).UserPrincipalName -icontains $UserUPN)
        {
        Write-Host "The user" $UserUPN "is already a member of" $PioneerGroup "group" -ForegroundColor Red
        ;return
        }
        elseif ((Get-AzureADUser -ObjectId $AADUser.ObjectID).AccountEnabled -eq $false)
        {
        Write-Host "Can not add" $UserUPN "because of Block sign in configuration" -ForegroundColor Red
        ;return
        }

        elseif  (Get-AzureADTenantDetail | Where-Object {$_.ObjectId -eq "c21157ca-bce3-41a8-8aa7-a23c4639610a"} )  
               {
           Write-Host ""
           Write-Host "Your AAD session is online ... We will be Glad To Process Your Order !" -ForegroundColor Yellow
           Write-Host ""
           Add-AzureADGroupMember -ObjectId $AADSecGroup.ObjectID -RefObjectId $AADUser.ObjectID
           Write-Host "The UserName:    $UserUPN Has Been Added To The Group :   $PioneerGroup" -ForegroundColor Green
     
               }
        else {
            Write-host "We Are Sorry For This Inconvenience, Your AAD Session Seems To Be Offline ... Please Connect To AzureAD Then Re-Launch Your Request ."
        
             }


            } 
          catch [Microsoft.Open.Azure.AD.CommonLibrary.AadNeedAuthenticationException] 
                {
               Write-Host "" 
               Write-Host "We Are Sorry For This Inconvenience, Your AAD Session Seems To Be Offline ... Please Connect To AzureAD Then Re-Launch Your Request ." -ForegroundColor Magenta;  
               Write-Host ""
                }
    }


function RemovePionnerUser{

    Param(
    [parameter(mandatory=$True)]
            
        [string]$UserUPN,
        [string]$PioneerGroup
        )
        $UserUPN = $UserUPN.Trim()
        $PioneerGroup = $PioneerGroup.Trim()
        try 
            { 
            if ((Get-AzureADUser -Filter "UserPrincipalName eq '$UserUPN'") -ne $null)
                {$UserUPN = (Get-AzureADUser -Filter "UserPrincipalName eq '$UserUPN'").UserPrincipalName
                    }
            elseif((Get-AzureADUser -Filter "mail eq '$UserUPN'") -ne $null)
                {$UserUPN = (Get-AzureADUser -Filter "mail eq '$UserUPN'").UserPrincipalName
                    }
               else 
                {$UserUPN = Get-AzureADUser -ObjectId $UserUPN
                    }
            } 

         catch [Microsoft.Open.AzureAD16.Client.ApiException] 
                { Write-Host "User" $UserUPN "does not exist in AzureAD" -ForegroundColor Red  
                ;return} 
        if ((Get-AzureADGroup  -Filter "DisplayName eq '$PioneerGroup'") -eq $null)
        {
        Write-Host "The group" $PioneerGroup "does not exist in AzureAD" -ForegroundColor Red
        ;return
        }

        
        try {
            $ShellConnetion = Get-AzureADTenantDetail
            $AADGroup = Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'"
            $AADUser  = Get-AzureADUser -Filter "UserPrincipalName eq '$UserUPN'"
            $Cid = ((Get-AzureADCurrentSessionInfo).Account).Id
            $glist = (Get-AzureADGroupOwner -ObjectId (Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'").ObjectID -All $true).UserPrincipalName 

        if ($glist -inotcontains $Cid)
        {
        Write-Host "You do not have permission to do this task, please validate your privileges for this group" $PioneerGroup -ForegroundColor Red 
        ;return
        }
        elseif ((Get-AzureADGroupMember -ObjectId (Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'").ObjectId -All $true).UserPrincipalName -inotcontains $UserUPN)
        {
        Write-Host "The user" $UserUPN "is not a member of" $PioneerGroup "group" -ForegroundColor Red
        ;return
        }

        elseif ( Get-AzureADTenantDetail | Where-Object {$_.ObjectId -eq "c21157ca-bce3-41a8-8aa7-a23c4639610a"}) 
                   {
            Write-Host ""
            Write-Host "Your AAD session is online ... We will be Glad To Process Your Order !" -ForegroundColor Yellow
            Write-Host ""
            Remove-AzureADGroupMember -ObjectId $AADGroup.ObjectID -MemberId $AADUser.ObjectID
            Write-Host "The UserName:    $UserUPN Has Been Removed From The Group :   $PioneerGroup" -ForegroundColor Red
         
                   }
        else {
            Write-host "We Are Sorry For This Inconvenience, Your AAD Session Seems To Be Offline ... Please Connect To AzureAD Then Re-Launch Your Request ."
            
                 }
    
    
                } 
            catch [Microsoft.Open.Azure.AD.CommonLibrary.AadNeedAuthenticationException] 
                 {
                Write-Host "" 
                Write-Host "We Are Sorry For This Inconvenience, Your AAD Session Seems To Be Offline ... Please Connect To AzureAD Then Re-Launch Your Request ." -ForegroundColor Magenta;  
                Write-Host ""
                 }
    
    }


function AddBulkPionnerUsers{

        Param(
        [parameter(mandatory=$True)]
            
            [string]$CSVFiles,
            [string]$PioneerGroup
            )
                            ###pathout
                    [string]$date = (Get-Date)
                    $date = $date.Split(',') -replace "/", "-" -replace ":", "-" -replace " ", '_'
                    $name = "$PioneerGroup-$date"
                    $pathOut = "$($env:USERPROFILE)\Desktop\$name.csv"


     #{} | Select "Username","Status","Groupname","Comments","AADStatus","ADStatus" | Export-Csv $pathOut -NoTypeInformation
     "Username,Status,Groupname,Comments,AADStatus,ADStatus" | Out-File $pathOut

        #$out | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1 | Out-File $pathOut

    
        $PioneerGroup = $PioneerGroup.Trim()
        $Cid = ((Get-AzureADCurrentSessionInfo).Account).Id

        
        if ((Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'" -All $true) -eq $null)
        {
        Write-Host "The group" $PioneerGroup "does not exist in AzureAD" -ForegroundColor Red
        ;return
        }
        $glist = (Get-AzureADGroupOwner -ObjectId (Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'").ObjectID -All $true).UserPrincipalName 
        if ($glist -inotcontains $Cid)
        {
        Write-Host "You do not have permission to do this task, please validate your privileges for this group" $PioneerGroup -ForegroundColor Red 
        ;return
        }


      
                      
               Try { 
                      $ShellConnetion = Get-AzureADTenantDetail     
                      #$ErrorActionPreference = 'SilentlyContinue'
                      $AADSecGroup = Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'"
                      $membersGroup1 = Get-content $CSVFiles
                      }
                                    catch [Microsoft.Open.Azure.AD.CommonLibrary.AadNeedAuthenticationException] {
              Write-Host "" 
                   Write-Host "We Are Sorry For This Inconvenience, Your AAD Session Seems To Be Offline ... Please Connect To AzureAD Then Re-Launch Your Request ." -ForegroundColor Magenta;  
                   Write-Host ""
                    } 
       


       foreach($member in $membersGroup1)
       {
       $member = $member.trim()
        try 
            { if ((Get-AzureADUser -Filter "UserPrincipalName eq '$member'") -ne $null)
                {$member = (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").UserPrincipalName
                $memberad = (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").Mail
                    }
              elseif((Get-AzureADUser -Filter "mail eq '$member'") -ne $null)
                {$member = (Get-AzureADUser -Filter "mail eq '$member'").UserPrincipalName
                $memberad = (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").Mail
                    }
              else 
                {$member1 = Get-AzureADUser -ObjectId $member
                $memberad = $member.Mail
                $member1 = $member.UserPrincipalName
                    }

             if ((Get-AzureADGroupMember -ObjectId $AADSecGroup.ObjectId -All $true).UserPrincipalName -icontains $member)
        {
        Write-Host "The user" $member "is already a member of" $PioneerGroup "group" -ForegroundColor Red
                $Username = $member
        $Status = 'Not-Added'
        $Groupname = $PioneerGroup
        $Comments = 'Already in Group'
        if ((((Get-ADuser -Filter "UserPrincipalName -eq '$memberad'" -Properties *).Enabled) -contains $true) -or (((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $true))
        {
        $ADStatus = 'Active'
        }
        elseif((((Get-ADuser -Filter "UserPrincipalName -eq '$memberad'" -Properties *).Enabled) -contains $false) -or (((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $false))
        {
        $ADStatus = 'Disable'
        }
        elseif((((Get-ADuser -Filter "UserPrincipalName -eq '$memberad'" -Properties *).Enabled) -contains $null) -or (((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $null))
        {
        $ADStatus = 'Not Found'
        }

        if ( (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").AccountEnabled -eq $true)
        {
        $AADStatus = 'Active'
        }
        elseif( (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").AccountEnabled -eq $false)
        {
        $AADStatus = 'Disable'
        }
        elseif( (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").AccountEnabled -eq $null)
        {
        $AADStatus = 'Not Found'
        }
         $out = [pscustomObject]@{
         Username = $Username;
         Status = $Status;
         Groupname = $Groupname;
         Comments = $Comments;
         AADStatus = $AADStatus;
         ADStatus = $ADStatus;}
         
          $out | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1 | Out-File $pathOut -Append
        }
        elseif ((Get-AzureADUser -ObjectId (Get-AzureADUser -ObjectId $member).ObjectID).AccountEnabled -eq $false)
        {
        Write-Host "Can not add" $member "because of Block sign in configuration" -ForegroundColor Red
                $Username = $member
        $Status = 'Not-Added'
        $Groupname = $PioneerGroup
        $Comments = 'Block Sign in'
        if ((((Get-ADuser -Filter "UserPrincipalName -eq '$memberad'" -Properties *).Enabled) -contains $true) -or (((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $true))
        {
        $ADStatus = 'Active'
        }
        elseif((((Get-ADuser -Filter "UserPrincipalName -eq '$memberad'" -Properties *).Enabled) -contains $false) -or (((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $false))
        {
        $ADStatus = 'Disable'
        }
        elseif((((Get-ADuser -Filter "UserPrincipalName -eq '$memberad'" -Properties *).Enabled) -contains $null) -or (((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $null))
        {
        $ADStatus = 'Not Found'
        }

        if ( (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").AccountEnabled -eq $true)
        {
        $AADStatus = 'Active'
        }
        elseif( (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").AccountEnabled -eq $false)
        {
        $AADStatus = 'Disable'
        }
        elseif( (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").AccountEnabled -eq $null)
        {
        $AADStatus = 'Not Found'
        }        
         $out = [pscustomObject]@{
         Username = $Username;
         Status = $Status;
         Groupname = $Groupname;
         Comments = $Comments;
         AADStatus = $AADStatus;
         ADStatus = $ADStatus;}         
          $out | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1 | Out-File $pathOut -Append
        }
        elseif ( Get-AzureADTenantDetail | Where-Object {$_.ObjectId -eq "c21157ca-bce3-41a8-8aa7-a23c4639610a"}) 
             {

               # $ConvertedGuids = Get-AzureADUser -SearchString "$member" | Select -ExpandProperty ObjectId  
               $ConvertedGuids = Get-AzureADUser -ObjectId "$member" | Select -ExpandProperty ObjectId 
               
               
                Add-AzureADGroupMember -ObjectId $AADSecGroup.ObjectID -RefObjectId "$ConvertedGuids"
                Write-Host "The UserName:    $member Has Been Added To The Group :   $PioneerGroup" -ForegroundColor Green
            $Username = $member
            $Status = 'Added'
            $Groupname = $PioneerGroup
            $Comments = 'Member has been added to the group'
        if ((((Get-ADuser -Filter "UserPrincipalName -eq '$memberad'" -Properties *).Enabled) -contains $true) -or (((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $true))
        {
        $ADStatus = 'Active'
        }
        elseif((((Get-ADuser -Filter "UserPrincipalName -eq '$memberad'" -Properties *).Enabled) -contains $false) -or (((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $false))
        {
        $ADStatus = 'Disable'
        }
        elseif((((Get-ADuser -Filter "UserPrincipalName -eq '$memberad'" -Properties *).Enabled) -contains $null) -or (((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $null))
        {
        $ADStatus = 'Not Found'
        }

        if ( (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").AccountEnabled -eq $true)
        {
        $AADStatus = 'Active'
        }
        elseif( (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").AccountEnabled -eq $false)
        {
        $AADStatus = 'Disable'
        }
        elseif( (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").AccountEnabled -eq $null)
        {
        $AADStatus = 'Not Found'
        }            
            $out = [pscustomObject]@{
         Username = $Username;
         Status = $Status;
         Groupname = $Groupname;
         Comments = $Comments;
         AADStatus = $AADStatus;
         ADStatus = $ADStatus;}         
          $out | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1 | Out-File $pathOut -Append
                }
         else  {
            Write-host "We Are Sorry For This Inconvenience, Your AAD Session Seems To Be Offline ... Please Connect To AzureAD Then Re-Launch Your Request ."
 }
              } 
              catch [Microsoft.Open.AzureAD16.Client.ApiException] 
                { Write-Host "User" $member.trim() "does not exist in AzureAD" -ForegroundColor Red 
            $Username = $member
            $Status = 'Not-Added'
            $Groupname = $PioneerGroup
            $Comments = 'User does not exist in AzureAD'
            $AADStatus = 'Not Found'

             try {
             $ADLocal=$(Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled

                     if ((((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $true) -or (((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $true))
                    {
                    $ADStatus = 'Active'
                    }
                    elseif((((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $false) -or (((Get-ADuser -Filter "UserPrincipalName -eq '$member'" -Properties *).Enabled) -contains $false))
                    {
                    $ADStatus = 'Disable'
                    }
                  } 
             catch
             {
             $ADStatus = 'Not Found'
             } 
          $out = [pscustomObject]@{
         Username = $Username;
         Status = $Status;
         Groupname = $Groupname;
         Comments = $Comments;
         AADStatus = $AADStatus;
         ADStatus = $ADStatus;}         
          $out | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1 | Out-File $pathOut -Append
                } 
 

 
 
 }
  Write-Host "Output Results:- "$pathOut -ForegroundColor Green
 }


function RemoveBulkPionnerUsers{

        Param(
        [parameter(mandatory=$True)]
            
            [string]$CSVFiles,
            [string]$PioneerGroup
            )
        $PioneerGroup = $PioneerGroup.Trim()
        $Cid = ((Get-AzureADCurrentSessionInfo).Account).Id

        
        if ((Get-AzureADGroup  -Filter "DisplayName eq '$PioneerGroup'" -All $true) -eq $null)
        {
        Write-Host "The group" $PioneerGroup "does not exist in AzureAD" -ForegroundColor Red
        ;return
        }
        $glist = (Get-AzureADGroupOwner -ObjectId (Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'").ObjectID -All $true).UserPrincipalName 
        if ($glist -inotcontains $Cid)
        {
        Write-Host "You do not have permission to do this task, please validate your privileges for this group" $PioneerGroup -ForegroundColor Red 
        ;return
        }


      
                      
               Try { 
                      $ShellConnetion = Get-AzureADTenantDetail     
                      #$ErrorActionPreference = 'SilentlyContinue'
                      $AADSecGroup = Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'"
                      $membersGroup1 = Get-content $CSVFiles
                      }
                                    catch [Microsoft.Open.Azure.AD.CommonLibrary.AadNeedAuthenticationException] {
              Write-Host "" 
                   Write-Host "We Are Sorry For This Inconvenience, Your AAD Session Seems To Be Offline ... Please Connect To AzureAD Then Re-Launch Your Request ." -ForegroundColor Magenta;  
                   Write-Host ""
                    } 
       


       foreach($member in $membersGroup1)
       {
       $member = $member.trim()
        try 
            { 
                if ((Get-AzureADUser -Filter "UserPrincipalName eq '$member'") -ne $null)
                    {$member = (Get-AzureADUser -Filter "UserPrincipalName eq '$member'").UserPrincipalName
                    }
                elseif((Get-AzureADUser -Filter "mail eq '$member'") -ne $null)
                    {$member = (Get-AzureADUser -Filter "mail eq '$member'").UserPrincipalName
                    }
                else 
                    {$member = Get-AzureADUser -ObjectId $member
                    }
             if ((Get-AzureADGroupMember -ObjectId $AADSecGroup.ObjectId -All $true).UserPrincipalName -inotcontains $member)
        {
        Write-Host "The user" $member "is not a member of" $PioneerGroup "group" -ForegroundColor Red
        }
        elseif ( Get-AzureADTenantDetail | Where-Object {$_.ObjectId -eq "c21157ca-bce3-41a8-8aa7-a23c4639610a"}) 
             {

               # $ConvertedGuids = Get-AzureADUser -SearchString "$member" | Select -ExpandProperty ObjectId  
               $AADUser  = Get-AzureADUser -Filter "UserPrincipalName eq '$member'"
               
               Remove-AzureADGroupMember -ObjectId $AADSecGroup.ObjectID -MemberId $AADUser.ObjectID
              
                Write-Host "The UserName:    $member Has Been Removed To The Group :   $PioneerGroup" -ForegroundColor Green
                }
         else  {
            Write-host "We Are Sorry For This Inconvenience, Your AAD Session Seems To Be Offline ... Please Connect To AzureAD Then Re-Launch Your Request ."
 }
              } 
              catch [Microsoft.Open.AzureAD16.Client.ApiException] 
                { Write-Host "User" $member.trim() "does not exist in AzureAD" -ForegroundColor Red 
                } 
 

 
 
 }

 }



function ViewPionnerList{

                Param(
                [parameter(mandatory=$True)]
                    
                    [string]$PioneerGroup
                    )
                    $PioneerGroup = $PioneerGroup.trim()
                    if ((Get-AzureADGroup  -Filter "DisplayName eq '$PioneerGroup'" -All $true) -eq $null)
        {
        Write-Host "The group" $PioneerGroup "does not exist in AzureAD" -ForegroundColor Red
       
        }
                     elseif ((Get-AzureADGroupMember -ObjectId (Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'" -All $true).ObjectID) -eq $Null )
{
Write-Host "The group" $PioneerGroup "Is Empty !!" -ForegroundColor Red
}
                     else
                     {
                    $AADSecGroup = Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'"
                    $ndu = (Get-AzureADGroupMember -ObjectId $AADSecGroup.ObjectID -All $true).count
                    Get-AzureADGroupMember -ObjectId $AADSecGroup.ObjectID -All $true| Select DisplayName, UserPrincipalName, TelephoneNumber, Department , JobTitle | Out-GridView -Title "Name of Group: $PioneerGroup | Total number of users:  $ndu"
                    
                    }
                    }

function ExportPionnerList{

                Param(
                [parameter(mandatory=$True)]
                    
                    [string]$PioneerGroup
                    )
                    $PioneerGroup = $PioneerGroup.trim()
                    if ((Get-AzureADGroup  -Filter "DisplayName eq '$PioneerGroup'" -All $true) -eq $null)
        {
        Write-Host "The group" $PioneerGroup "does not exist in AzureAD" -ForegroundColor Red
       
        }
                     elseif ((Get-AzureADGroupMember -ObjectId (Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'" -All $true).ObjectID) -eq $Null )
{
Write-Host "The group" $PioneerGroup "Is Empty !!" -ForegroundColor Red
}
                     else
                     {
                    $AADSecGroup = Get-AzureADGroup -Filter "DisplayName eq '$PioneerGroup'"
                    $ndu = (Get-AzureADGroupMember -ObjectId $AADSecGroup.ObjectID -All $true).count
                    [string]$date = (Get-Date)
                    $date = $date.Split(',') -replace "/", "-" -replace ":", "-" -replace " ", '_'
                    $name = "$PioneerGroup-$date"
                    $pathOut = "$($env:USERPROFILE)\Desktop\$name.csv"
                    Get-AzureADGroupMember -ObjectId $AADSecGroup.ObjectID -All $true | Select DisplayName, UserPrincipalName, TelephoneNumber, Department , JobTitle  | Export-Csv -Path $pathOut -NoTypeInformation -Encoding Default -Force
                    Write-Host ("The Result File :- " + $pathOut) -ForegroundColor red
                    
                    }
                    }

function ADDAzureADGroup{

            Param(
                [parameter(mandatory=$True)]
                    
                    [string]$grpname
                    )
            $mailnick = $grpname.replace(' ' , '-')
            $mailnick = $mailnick.Trim()
            $objid = (Get-AzureADGroup -Filter "DisplayName eq '$grpname'").objectID
            if ($objid -eq $Null)
            {

               $ngrp = New-AzureADGroup -Description "$grpname" -DisplayName "$grpname" -MailEnabled $false -SecurityEnabled $true -MailNickName "$mailnick"
                Write-host "The following group has been created: "  $grpname -ForegroundColor Green 
                 }
            else
            {
            Write-Host "The following group is already exists in AzureAd: "$group  -ForegroundColor Red
    
            }  


            $objid = (Get-AzureADGroup -Filter "DisplayName eq '$grpname'").objectID

            try{
                $servicePrincipal = Get-AzureADServicePrincipal -ObjectId '09eff5cd-d3d1-47f3-8673-a6ab6b7bb16b' #Netskope APP
                New-AzureADGroupAppRoleAssignment -ObjectId $objid -PrincipalId $objid -ResourceId $servicePrincipal.ObjectId -Id $servicePrincipal.Approles[0].id -ErrorAction Stop
                Write-host "The following group has been added to Netskope Provisioning APP: "  $grpname -ForegroundColor Green
            }

            catch{
                Write-host "The following group is already associated with Netskope Provisioning APP: "  $grpname -ForegroundColor Red
                }
            
            #Get-AzureADServiceAppRoleAssignment -all $true -ObjectId $servicePrincipal.Objectid #get all associated grup

             #casb-admins
            $casbadmin = (Get-AzureADGroupMember -ObjectId 'a86e3463-59b5-4d27-89da-5ad7470f8726').UserPrincipalName

            foreach($user in $casbadmin){
                    $refid = (Get-AzureADUser -filter "UserPrincipalName eq '$user'").ObjectId
                    
            try{
                Add-AzureADGroupOwner -ObjectId $objid -RefObjectId $refid

                Write-host "Added "  $user  " as group Owner" -ForegroundColor Green
                }

            catch{
                Write-host "The user: "  $user  " is already a group Owner" -ForegroundColor Red
                }
}}


function RemoveAzureADGroupOwner{
            Param(
                [parameter(mandatory=$True)]
                    
                    [string]$username
                    )
            $username = $username.Trim()
            try 
            { $val1 = Get-AzureADUser -ObjectId $username} 

            catch [Microsoft.Open.AzureAD16.Client.ApiException] 
            { Write-Host "User" $username "does not exist in AzureAD" -ForegroundColor Red  
                ;return}
            $servicePrincipal = Get-AzureADServicePrincipal -ObjectId '09eff5cd-d3d1-47f3-8673-a6ab6b7bb16b' #Netskope APP
            $casbgroup = (Get-AzureADServiceAppRoleAssignment -all $true -ObjectId $servicePrincipal.Objectid).PrincipalDisplayName #get all associated grup
            $usrID = (Get-AzureADuser -Filter "UserPrincipalName eq '$username'").ObjectId
            $Cid = ((Get-AzureADCurrentSessionInfo).Account).Id
            foreach($group in $casbgroup)  {
            #$group
            try 
            { 
            $grpID = (Get-AzureADGroup -Filter "DisplayName eq '$group'").ObjectId 
            $glist = (Get-AzureADGroupOwner -ObjectId $grpID -All $true).UserPrincipalName 
        
        
            if ($glist -inotcontains $Cid)
            {
            Write-Host "You do not have permission to do this task, please validate your privileges for this group" $group -ForegroundColor Red 
                 }
            elseif ($glist -inotcontains $username) 
            {
            Write-Host "The user" $username "is not an admin of" $group "group" -ForegroundColor Red
    
            }  
            
            else 
             {

            Remove-AzureADGroupOwner -ObjectId $grpID -OwnerId $usrID
            Write-Host "The UserName:    $username Has Been Removed From The Group :   $group" -ForegroundColor Green

             }

             }
            catch {
              }
}}

function ADDAzureADGroupOwner{

            Param(
                [parameter(mandatory=$True)]
                    
                    [string]$username
                    )
            $username = $username.Trim()
            try 
            { $val1 = Get-AzureADUser -ObjectId $username} 

            catch [Microsoft.Open.AzureAD16.Client.ApiException] 
            { Write-Host "User" $username "does not exist in AzureAD" -ForegroundColor Red  
                ;return}

            $servicePrincipal = Get-AzureADServicePrincipal -ObjectId '09eff5cd-d3d1-47f3-8673-a6ab6b7bb16b' #Netskope APP
            $casbgroup = (Get-AzureADServiceAppRoleAssignment -all $true -ObjectId $servicePrincipal.Objectid).PrincipalDisplayName #get all associated grup
            $usrID = (Get-AzureADuser -Filter "UserPrincipalName eq '$username'").ObjectId
            $Cid = ((Get-AzureADCurrentSessionInfo).Account).Id
            foreach($group in $casbgroup)  {
            #$group
            try 
            { 
            $grpID = (Get-AzureADGroup -Filter "DisplayName eq '$group'").ObjectId 
            $glist = (Get-AzureADGroupOwner -ObjectId $grpID -All $true).UserPrincipalName 
        
        
            if ($glist -inotcontains $Cid)
            {
            Write-Host "You do not have permission to do this task, please validate your privileges for this group" $group -ForegroundColor Red 
                 }
            elseif ($glist -icontains $username) 
            {
            Write-Host "The user" $username "is already an admin of" $group "group" -ForegroundColor Red
    
            }  
            
            else 
             {

            ADD-AzureADGroupOwner -ObjectId $grpID -RefObjectId $usrID
            Write-Host "The UserName:    $username Has Been Added To The Group :   $group" -ForegroundColor Green

             }

             }
            catch {
              }
}}

function RemoveAzureADGroup{

            Param(
                [parameter(mandatory=$True)]
                    
                    [string]$grpname
                    )

                  try 
            { 
            $Cid = ((Get-AzureADCurrentSessionInfo).Account).Id
            $grpID = (Get-AzureADGroup -Filter "DisplayName eq '$grpname'").ObjectId
            $glist = (Get-AzureADGroupOwner -ObjectId $grpID -All $true).UserPrincipalName
                    
            }
            catch {
            Write-Host 'The Following Group Does Not Exists ' $grpname
            return;

              }


            $title    = 'Warning'
            $question = 'You are going to delete a group, this action is irreversible.
                        Are you sure you want to proceed further'

            $choices = New-Object Collections.ObjectModel.Collection[Management.Automation.Host.ChoiceDescription]
            $choices.Add((New-Object Management.Automation.Host.ChoiceDescription -ArgumentList '&Yes'))
            $choices.Add((New-Object Management.Automation.Host.ChoiceDescription -ArgumentList '&No'))

            $decision = $Host.UI.PromptForChoice($title, $question, $choices, 1)
            if ($decision -eq 0) {
            try 
            { 
            Remove-AzureADGroup -ObjectId $grpID
            Write-Host 'The Following Group Has Been Deleted ' $grpname
            }
            catch {
              }
            
            } else {
                
                return;
                
            }


            
}
function CASBAzureADGroup{
$servicePrincipal = Get-AzureADServicePrincipal -ObjectId '09eff5cd-d3d1-47f3-8673-a6ab6b7bb16b' #Netskope APP
$casbgroup = (Get-AzureADServiceAppRoleAssignment -all $true -ObjectId $servicePrincipal.Objectid).PrincipalDisplayName
[string]$date = (Get-Date)
$date = $date.Split(',') -replace "/", "-" -replace ":", "-" -replace " ", '_'
$name = 'AzureAd-Output'
$name = "$name-$date"
$pathOut = "$($env:USERPROFILE)\Desktop\$name"
New-Item -Path $pathOut -ItemType Directory | Out-Null
$gcsv = "$pathOut\Summary.csv"
{} | Select "Groupname","Usercount","Type" | Export-Csv $gcsv -NoTypeInformation
foreach($group in $casbgroup)  {
if ($group -inotlike 'AAD-SEC-DYN-USER-BNC EMPLOYEES' -and $group -inotlike 'AAD-SEC-DYN-USER-BNC CONSULTANTS' ){ 
$outcsv = "$pathOut\$group.csv"
 {} | Select "Username","Email","AccountEnabled","JobTitle","Department" | Export-Csv $outcsv -NoTypeInformation
 }

    
            #$group
            
            if ($group -inotlike 'AAD-SEC-DYN-USER-BNC EMPLOYEES' -and $group -inotlike 'AAD-SEC-DYN-USER-BNC CONSULTANTS' ){ 
                
                $gtype = $null
                if([string]$group.contains("AAD-SEC-MGM") -eq $true){
                $gtype = 'Exception'
                }
                elseif ([string]$group.contains("AAD-SEC-CASB") -eq $true)
                {
                $gtype = 'Config'
                }
                else
                {
                $gtype = 'Other'
                }
            $grpID = (Get-AzureADGroup -Filter "DisplayName eq '$group'").ObjectId 
            $glist = (Get-AzureADGroupmember -ObjectId $grpID -All $true).ObjectId
                $gout = [pscustomObject]@{
                Groupname = $group;
                Usercount = $glist.Count;
                Type = $gtype;}
                $gout | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1 | Out-File $gcsv -Append
                $c1 = 0
            foreach($member in $glist)  {
            Write-Progress -Id 0 -Activity "Working on $group" -Status "Processing $($c1) of $($glist.count)" -CurrentOperation $uri -PercentComplete (($c1/$glist.Count) * 100)
            $c1++;
            $info = Get-AzureADUser -ObjectId $member
            $out = [pscustomObject]@{
             Username = $info.DisplayName;
             Email = $info.UserPrincipalName ;
             AccountEnabled = $info.AccountEnabled;
             JobTitle = $info.JobTitle;
             Department = $info.Department;}
             $out | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1 | Out-File $outcsv -Append

            }
              } }
Write-Host ("The Result File :- " + $pathOut) -ForegroundColor red              }

function CompareAzureADGroup{
            Param(
                [parameter(mandatory=$True)]
                    
                    [string]$grpname1,
                    [string]$grpname2
                    )

            try 
            { 
            $Cid = ((Get-AzureADCurrentSessionInfo).Account).Id
            $grpID1 = (Get-AzureADGroup -Filter "DisplayName eq '$grpname1'").ObjectId
            $glist1 = (Get-AzureADGroupMember -ObjectId $grpID1 -All $true).UserPrincipalName
            $grpID2 = (Get-AzureADGroup -Filter "DisplayName eq '$grpname2'").ObjectId
            $glist2 = (Get-AzureADGroupMember -ObjectId $grpID2 -All $true).UserPrincipalName
                    
            }
            catch {
            Write-Host 'The Group Does Not Exists '
            return;

              }
            [string]$date = (Get-Date)
            $date = $date.Split(',') -replace "/", "-" -replace ":", "-" -replace " ", '_'
            $pathOut = $pathOut = "$($env:USERPROFILE)\Desktop\Compare-$date.csv"
            try {
            $compare = Compare-Object -ReferenceObject $glist1 -DifferenceObject $glist2  -IncludeEqual
            }
            catch {
            Write-Host 'One of the group is empty !! '
                        return;
            }
            $table = New-Object System.Data.Datatable
            # Adding columns
            [void]$table.Columns.Add("InBothGroup")
            [void]$table.Columns.Add("Only-In-$grpname1")
            [void]$table.Columns.Add("Only-In-$grpname2")
            foreach ($line in $compare)
            {
            if ($line.SideIndicator -eq "==")
            {
            $value1 = $line.InputObject
            [void]$table.Rows.Add("$value1","","")
            }
            elseif ($line.SideIndicator -eq "<=")
            {
            $value1 = $line.InputObject
            [void]$table.Rows.Add("","$value1","")
            }
            elseif ($line.SideIndicator -eq "=>")
            {
            $value1 = $line.InputObject
            [void]$table.Rows.Add("","","$value1")
            }

            }
            $table | Export-Csv $pathOut -NoTypeInfo -UseCulture
            Write-Host ("The Result File :- " + $pathOut) -ForegroundColor red

}