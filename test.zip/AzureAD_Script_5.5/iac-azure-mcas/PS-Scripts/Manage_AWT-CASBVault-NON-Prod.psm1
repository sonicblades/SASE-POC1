function FetchUserSteering{
 Param(
    [parameter(mandatory=$True)]
        
        [string]$usremail,
        [string]$token
        )
    #$token = Get-AzKeyVaultSecret -VaultName "CASB-5934-KEY" -Name "APIv1" -AsPlainText
    #$VaultLogin = Invoke-Expression -Command ".\vault login -method=oidc -path=azure-ad -address=https://vault-onprem.prd.bngf.local/" 2>&1>$null | out-null
    #$token = $(.\vault.exe kv get -address="https://vault-onprem.prd.bngf.local/" -field SteerAPI secret/applications/5934/production/production/SteeringAPI)
    $userkeyfile ="https://bncnpr.goskope.com/api/v1/userconfig?token="+$token+"&configtype=agent&email="+$usremail
    $userapi = Invoke-RestMethod "$userkeyfile"

    if ($userapi.status -eq 'error') {
    $sumemail = 8+$usremail.Length
    

    Write-host("================================================================")-ForegroundColor Red
    write-Host("{0,0}" -f "User Email: ") -ForegroundColor Red -NoNewline
    write-host("{0,$sumemail}" -f $usremail) -ForegroundColor Green
    Write-Host("{0,0}" -f "User Key: ") -ForegroundColor Red -NoNewline
    write-host("{0,19}" -f 'Not Found') -ForegroundColor Green
    Write-Host("{0,0}" -f "Steering Config: ") -ForegroundColor Red -NoNewline
    write-host("{0,12}" -f 'Not Found') -ForegroundColor Green
    Write-Host("{0,0}" -f "Traffic Mode: ") -ForegroundColor Red -NoNewline
    write-host("{0,15}" -f "Not Found") -ForegroundColor Green
    Write-host("================================================================")-ForegroundColor Red
    }
    else{

    $userkey = $userapi.data.brandingdata.UserKey
    $urlsteering = "https://addon-bncnpr.goskope.com/v1/steering/domains?userkey="+$userkey+"&orgkey=hat2MnxB9dj4K0mkx&os=win"
    $sapi = Invoke-RestMethod $urlsteering        
    $steeringconfigname = $sapi.steering_config_name
    $trafficmode = $sapi.traffic_mode
    $sumemail = 8+$usremail.Length
    $sumkey = 10+ $userkey.Length
    $sumconfig = 3+$steeringconfigname.Length
    $summode = 6+$trafficmode.Length

    Write-host("================================================================")-ForegroundColor Red
    write-Host("{0,0}" -f "User Email: ") -ForegroundColor Red -NoNewline
    write-host("{0,$sumemail}" -f $usremail) -ForegroundColor Green
    Write-Host("{0,0}" -f "User Key: ") -ForegroundColor Red -NoNewline
    write-host("{0,$sumkey}" -f $userkey) -ForegroundColor Green
    Write-Host("{0,0}" -f "Steering Config: ") -ForegroundColor Red -NoNewline
    write-host("{0,$sumconfig}" -f $steeringconfigname) -ForegroundColor Green
    Write-Host("{0,0}" -f "Traffic Mode: ") -ForegroundColor Red -NoNewline
    write-host("{0,$summode}" -f $trafficmode) -ForegroundColor Green
    Write-host("================================================================")-ForegroundColor Red

    }
    
    }

function FetchUserSteeringbulk{
 Param(
    [parameter(mandatory=$True)]
        
        [string]$csv,
        [string]$fname,
        [string]$token
        )

[string]$date = (Get-Date)
$date = $date.Split(',') -replace "/", "-" -replace ":", "-" -replace " ", '_'
#$pathOut = "$($env:USERPROFILE)\Desktop\$fname"+"_$date.csv"
$pathOut = "$fname"+"_$date.csv"
{}|Select "User Email","User Key","Steering Config","Traffic Mode"|Export-Csv $pathOut -NoTypeInformation
foreach($usremail in Get-Content $csv){

    #$token = Get-AzKeyVaultSecret -VaultName "CASB-5934-KEY" -Name "APIv1" -AsPlainText
    #$VaultLogin = Invoke-Expression -Command ".\vault login -method=oidc -path=azure-ad -address=https://vault-onprem.prd.bngf.local/" 2>&1>$null | out-null
    #$token = $(.\vault.exe kv get -address="https://vault-onprem.prd.bngf.local/" -field SteerAPI secret/applications/5934/production/production/SteeringAPI)
    $userkeyfile ="https://bncnpr.goskope.com/api/v1/userconfig?token="+$token+"&configtype=agent&email="+$usremail
    $userapi = Invoke-RestMethod "$userkeyfile"
        if ($userapi.status -eq 'error') {
    $sumemail = 8+$usremail.Length
    $userkey = 'Not Found'
    $steeringconfigname = 'Not Found'
    $trafficmode = 'Not Found'   

    Write-host("================================================================")-ForegroundColor Red
    write-Host("{0,0}" -f "User Email: ") -ForegroundColor Red -NoNewline
    write-host("{0,$sumemail}" -f $usremail) -ForegroundColor Green
    Write-Host("{0,0}" -f "User Key: ") -ForegroundColor Red -NoNewline
    write-host("{0,19}" -f 'Not Found') -ForegroundColor Green
    Write-Host("{0,0}" -f "Steering Config: ") -ForegroundColor Red -NoNewline
    write-host("{0,12}" -f 'Not Found') -ForegroundColor Green
    Write-Host("{0,0}" -f "Traffic Mode: ") -ForegroundColor Red -NoNewline
    write-host("{0,15}" -f "Not Found") -ForegroundColor Green
    Write-host("================================================================")-ForegroundColor Red
    }
    else{

    $userkey = $userapi.data.brandingdata.UserKey
    $urlsteering = "https://addon-bncnpr.goskope.com/v1/steering/domains?userkey="+$userkey+"&orgkey=hat2MnxB9dj4K0mkx&os=win"
    $sapi = Invoke-RestMethod $urlsteering        
    $steeringconfigname = $sapi.steering_config_name
    $trafficmode = $sapi.traffic_mode
    $sumemail = 8+$usremail.Length
    $sumkey = 10+ $userkey.Length
    $sumconfig = 3+$steeringconfigname.Length
    $summode = 6+$trafficmode.Length

    Write-host("================================================================")-ForegroundColor Red
    write-Host("{0,0}" -f "User Email: ") -ForegroundColor Red -NoNewline
    write-host("{0,$sumemail}" -f $usremail) -ForegroundColor Green
    Write-Host("{0,0}" -f "User Key: ") -ForegroundColor Red -NoNewline
    write-host("{0,$sumkey}" -f $userkey) -ForegroundColor Green
    Write-Host("{0,0}" -f "Steering Config: ") -ForegroundColor Red -NoNewline
    write-host("{0,$sumconfig}" -f $steeringconfigname) -ForegroundColor Green
    Write-Host("{0,0}" -f "Traffic Mode: ") -ForegroundColor Red -NoNewline
    write-host("{0,$summode}" -f $trafficmode) -ForegroundColor Green
    Write-host("================================================================")-ForegroundColor Red }
    $out = [pscustomObject]@{
                    UserEmail = $usremail;
                    UserKey = $userkey;
                    Steering = $steeringconfigname;
                    Traffic = $trafficmode;}
            
    $out | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1 | Out-File $pathOut -Append
    }
Write-Host "Output Results:- "$pathOut -ForegroundColor Green}