﻿$id = ((Get-AzureADCurrentSessionInfo).Account).Id
$group = '-COHORTE Telnat 28 octobre 2019'
$admin = (Get-AzureADGroupOwner -ObjectId (Get-AzureADGroup -Filter "DisplayName eq '$group'").ObjectID).UserPrincipalName 

$bool = $admin -icontains $id


# 1 logic :- if user is in admin list

if ($bool -eq 'true')

 {
 Write-Host 'i love you'
  }

  else
   {
 Write-Host 'The account'$id 'does not have permission to modify'$group 'group.'
  }

# 2  logic :- if user exist in active directory
$usr = 'navjot.singh12@bnc.ca'

try 
{ $var = Get-AzureADUser -ObjectId $usr
$var} 


catch [Microsoft.Open.AzureAD16.Client.ApiException] 
{ Write-Host "User does not exists" }

# 3 logic :- if groupe exist in ad

$group = '-COHORTE Telnat 28 octobre 2019'
try 
{ $var1 = Get-AzureADGroup  -Filter "DisplayName eq '$group'"} 

catch [Microsoft.Open.AzureAD16.Client.ApiException] 
{ Write-Host "Groupe does not exists" }


# 4 logic :- if user already exists in groupe or not
$usr = 'jeanmark.ayoub@bnc.ca'
(Get-AzureADGroupMember -ObjectId (Get-AzureADGroup -Filter "DisplayName eq 'AAD-SEC-CASB-Netskope-Pionnier-AWT-W2'" ).ObjectId).UserPrincipalName -contains $usr

